package com.example.a11st_app;

public class Movie {


    String rnum;
    String rank;
    String rankInten;
    String rankOldAndnew;
    String MovieCd;
    String movieNm;
    String openDt;
    String salesAmt;
    String salesShare;
    String salesInten;
    String salesChange;
    String salesAcc;
    String audiCnt;
    String audiChange;
    String audiAcc;
    String scrnCnt;
    String showCnt;

}
