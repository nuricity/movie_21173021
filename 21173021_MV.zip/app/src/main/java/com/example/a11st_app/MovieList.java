package com.example.a11st_app;

public class MovieList {

  MovieListResult boxOfficeResult;

}
