package com.example.a11st_app;

import java.util.ArrayList;

public class MovieListResult {

   String boxofficeType;
   String showRange;

    ArrayList<Movie> dailyBoxOfficeList = new ArrayList<Movie>();

}
